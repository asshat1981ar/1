
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

export default function NoBullMarketing() {
  return (
    <main className="bg-black text-white font-sans">
      {/* Hero Section */}
      <section className="min-h-screen flex flex-col justify-center items-center text-center px-6 py-16">
        <motion.h1 
          initial={{ opacity: 0, y: -20 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 0.8 }}
          className="text-5xl md:text-7xl font-bold max-w-4xl leading-tight mb-6"
        >
          STRATEGY ACTIVATED.
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }} 
          transition={{ delay: 0.5 }}
          className="text-xl md:text-2xl mb-8 max-w-2xl"
        >
          We don’t attend meetings. We build machines that make you money.
        </motion.p>
        <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white">
          Get The Proof <ArrowRight className="ml-2 w-5 h-5" />
        </Button>
      </section>

      {/* Differentiator Section */}
      <section className="py-20 px-6 bg-zinc-900">
        <h2 className="text-4xl font-bold text-center mb-12">What Makes Us Different</h2>
        <div className="max-w-5xl mx-auto text-center text-lg">
          <p className="mb-6">
            No interns. No buzzwords. Just elite operators executing the digital strategy your business actually needs.
          </p>
          <p>
            From performance creatives to full-stack funnel systems — we only build what drives revenue.
          </p>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-6 bg-black text-white">
        <div className="grid md:grid-cols-3 gap-10 max-w-6xl mx-auto text-center">
          <Card className="bg-red-600 text-white">
            <CardContent className="py-10">
              <p className="text-4xl font-bold">+214%</p>
              <p className="mt-2 text-sm">Lead Value Increase</p>
            </CardContent>
          </Card>
          <Card className="bg-white text-black">
            <CardContent className="py-10">
              <p className="text-4xl font-bold">+323%</p>
              <p className="mt-2 text-sm">Conversion Rate</p>
            </CardContent>
          </Card>
          <Card className="bg-zinc-800">
            <CardContent className="py-10">
              <p className="text-4xl font-bold">+157%</p>
              <p className="mt-2 text-sm">Click-Through Rate</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 px-6 bg-zinc-950">
        <h2 className="text-4xl font-bold text-center mb-16 text-white">What We Actually Do</h2>
        <div className="grid md:grid-cols-3 gap-10 max-w-6xl mx-auto text-white">
          <Card className="bg-zinc-800">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold mb-4">Sales Funnels</h3>
              <p>
                Full-funnel design and automation. Your MQLs become meetings — without you lifting a finger.
              </p>
            </CardContent>
          </Card>
          <Card className="bg-zinc-800">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold mb-4">Paid Media</h3>
              <p>
                Performance-driven creative & targeting systems that scale efficiently on Meta, Google, and YouTube.
              </p>
            </CardContent>
          </Card>
          <Card className="bg-zinc-800">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold mb-4">Landing Pages</h3>
              <p>
                UX-tested, conversion-obsessed pages that don't just look good — they print money.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-24 px-6 bg-red-600 text-center text-white">
        <h2 className="text-4xl font-bold mb-4">Ready to Ditch the Bull?</h2>
        <p className="text-lg mb-8">Book your free growth audit. Let’s get real about results.</p>
        <Button size="lg" className="bg-white text-black hover:bg-zinc-100">
          Book My Audit <ArrowRight className="ml-2 w-5 h-5" />
        </Button>
      </section>
    </main>
  );
}
